
# MDS5210-24fall Final Project

The final project code for the MDS5210-24fall . Please refer to the project manual for more detailed information.

## Acknowledgements

The project is based on [nanoGPT](https://github.com/karpathy/nanoGPT). Thanks for the great work!