import pickle
import time
import random
from transformers import GPT2Tokenizer

# Initialize the tokenizer
# tokenizer_path = f"gpt2-medium-tokenizer"
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')

out_dir = 'out-instruction-tuning'
eval_interval = 100  # adjust it to your need
eval_iters = 40
wandb_log = False  # feel free to turn on
wandb_project = 'instruction-tuning'
wandb_run_name = 'ft-' + str(time.time())

dataset = 'alpaca-gpt4'
init_from = 'gpt2-medium'  # this is the largest GPT-2 model

# only save checkpoints if the validation loss improves
always_save_checkpoint = False

# the number of examples per iter:
batch_size = 5
gradient_accumulation_steps = 2
max_iters = 5000

# finetune at constant LR
learning_rate = 1e-6
decay_lr = False

# load the data
train_samples = pickle.load(open("data/instruction_tuning/train.pkl", "rb"))
val_samples = pickle.load(open("data/instruction_tuning/val.pkl", "rb"))
END_TOKEN = 50256  # GPT-2's token for "<|endoftext|>"

# experiment setting for part 2
dtype = "bfloat16"  # float32, float16, bfloat16. Note that bfloat16 is not supported by P100 and some old GPUs.
optimization_method = "lora"  # adam, sgd, (lora or badam)


def get_batch_for_IT(split):
    """i.i.d. sample a batch of data, pad the batch into the same length for instruction tuning
    The pad token is suggested to be END_TOKEN defined above, which is the default choice for GPT-2 model series.
    
    Return:
        x: torch.tensor, shape=(batch_size, block_size)
        y: torch.tensor, shifted x, shape=(batch_size, block_size)
    """
    samples = train_samples if split == 'train' else val_samples
    
    batch = np.random.choice(len(samples)-block_size, batch_size)

    # Tokenize and find the maximum length
    tokenized_batch = [samples[i] for i in batch]
    max_length = block_size

    # Pad sequences to the maximum length using END_TOKEN
    padded_batch = [tokens[:block_size] + [END_TOKEN] * (max_length - len(tokens)) for tokens in tokenized_batch]

    # Convert to torch tensors
    x = torch.tensor(padded_batch, dtype=torch.long)

    # Shift x to create y
    y = x.clone()
    y[:, :-1] = x[:, 1:]
    y[:, -1] = END_TOKEN
    x, y = x.to(device), y.to(device)

    return x, y


def query_memory():
    """Query the memory usage of the GPU"""
    allocated_memory = torch.cuda.memory_allocated(device) / 1e9
    reserved_memory = torch.cuda.memory_reserved(device) / 1e9
    max_allocated_memory = torch.cuda.max_memory_allocated(device) / 1e9

    print(
        f"===Memory profile=== Allocated: {allocated_memory:.3f} GB, "
        f"Max allocated: {max_allocated_memory:.3f} GB, "
        f"Reserved: {reserved_memory:.3f} GB")

    return allocated_memory, reserved_memory, max_allocated_memory
