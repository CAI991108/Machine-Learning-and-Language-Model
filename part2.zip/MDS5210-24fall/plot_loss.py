import matplotlib.pyplot as plt
import pickle

with open('./out-instruction-tuning/loss_values.pkl', 'rb') as f:
    losses = pickle.load(f)

# Extract the training and validation loss values
train_losses = [d['train'].item() for d in losses]  # Convert tensors to Python numbers
val_losses = [d['val'].item() for d in losses]

print(f"Report the final loss at iteration 5000:",
      f"train loss: {train_losses[-1]:.4f}, val loss: {val_losses[-1]:.4f}")

# Create a range of epochs
iterations = range(0, 5100, 100)

plt.figure(figsize=(10, 5))
# Plot the training and validation losses
plt.plot(iterations, train_losses, label='Training Loss')
plt.plot(iterations, val_losses, label='Validation Loss')

# Add titles and labels
plt.title('Training Loss for GPT2-medium: LoRA-bfloat16 (lr=1e-6)')
plt.xlabel('Iterations')
plt.ylabel('Loss')
plt.legend()

# Show the plot
plt.show()