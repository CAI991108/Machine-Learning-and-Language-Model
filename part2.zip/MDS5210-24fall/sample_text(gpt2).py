from transformers import pipeline, set_seed

generator = pipeline('text-generation', model='gpt2')

set_seed(666)
max_length = 100
num_return_sequences = 1

generator(input_text,
          truncation=True,
          max_length=max_length,
          num_return_sequences=num_return_sequences,
          pad_token_id=50256)  # GPT-2's token for "

input_text = "Discuss the role of artificial intelligence in healthcare, specifically in diagnostics and patient care."
input_text = "Explain the concept of the butterfly effect in chaos theory and provide a real-world example."
input_text = "Discuss the potential consequences of climate change on global food security."
input_text = "Explain the concept of machine learning and how it differs from traditional programming."
input_text = ("Discuss the implications of the European Union's General Data Protection Regulation (GDPR) on "
              "international business operations and privacy rights.")
input_text = ("Examine the economic and social impacts of automation and artificial intelligence on the future of "
              "work, particularly in developing countries.")
input_text = ("Explain the concept of a universal basic income and debate its feasibility and potential impact on "
              "society and the economy.")
input_text = ("Discuss the role of cryptocurrency in the global financial system and its potential to disrupt "
              "traditional banking and monetary policy.")
input_text = ("Analyze the impact of the sharing economy on urban development, social dynamics, and environmental "
             "sustainability.")
input_text = ("A library has a collection of books where 40% are fiction and 60% are non-fiction. If the library "
              "removes 20% of its fiction books and 10% of its non-fiction books, what is the new percentage of "
              "fiction and non-fiction books in the collection?")

input_text = ("You have two boxes of crayons. Box A has 10 crayons, and you give 3 crayons to your friend. Then, "
              "you find another 5 crayons in your drawer. How many crayons do you have in total now?")
input_text = ("If you leave a glass of water outside on a cold night, and the temperature drops below 0, what will "
              "happen to the water in the glass?")
input_text = ("If you are at the South Pole and you walk in any direction, which direction are you walking in relative "
              "to the South Pole?")
input_text = "If you were born in 2010, how many years after the Wright brothers invented the airplane were you born?"
input_text = "If almost all birds can fly, and a penguin is a bird, can a penguin fly?"
input_text = ("A sequence is defined by the recurrence relation a_n=a_{n−1}+4 with the initial term a_1=1. What is the "
              "10th term of the sequence?")
input_text = ("In a group of 10 people, if 6 people can play the piano and 4 can play the violin, and no one can play "
              "both instruments, how many people can play at least one of the two instruments?")
input_text = ("A car travels at a constant speed of vv km/h. If it travels for tt hours, how far does it travel? "
              "v=60km/h, t=3 hours.")
input_text = ("A company's revenue increases by 10% each year. If the initial revenue was R dollars, what will be the "
              "revenue after 5 years? R=100,000 dollars.")
input_text = ("What is the molar mass of water (H₂O) given that the molar mass of hydrogen (H) is approximately 1 "
              "g/mol and oxygen (O) is approximately 16 g/mol?")
