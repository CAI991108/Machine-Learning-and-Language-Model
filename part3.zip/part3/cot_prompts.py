
def get_examples(task: list[str], num_shots: int):
    examples = {}
    examples['gsm8k']= [
        (
            "Angelo and Melanie want to plan how many hours over the next week they should study together for their test next week. They have 2 chapters of their textbook to study and 4 worksheets to memorize. They figure out that they should dedicate 3 hours to each chapter of their textbook and 1.5 hours for each worksheet. If they plan to study no more than 4 hours each day, how many days should they plan to study total over the next week if they take a 10-minute break every hour, include 3 10-minute snack breaks each day, and 30 minutes for lunch each day?",
            "Angelo and Melanie think they should dedicate 3 hours to each of the 2 chapters, 3 hours x 2 chapters = 6 hours total.\nFor the worksheets they plan to dedicate 1.5 hours for each worksheet, 1.5 hours x 4 worksheets = 6 hours total.\nAngelo and Melanie need to start with planning 12 hours to study, at 4 hours a day, 12 / 4 = 3 days.\nHowever, they need to include time for breaks and lunch. Every hour they want to include a 10-minute break, so 12 total hours x 10 minutes = 120 extra minutes for breaks.\nThey also want to include 3 10-minute snack breaks, 3 x 10 minutes = 30 minutes.\nAnd they want to include 30 minutes for lunch each day, so 120 minutes for breaks + 30 minutes for snack breaks + 30 minutes for lunch = 180 minutes, or 180 / 60 minutes per hour = 3 extra hours.\nSo Angelo and Melanie want to plan 12 hours to study + 3 hours of breaks = 15 hours total.\nThey want to study no more than 4 hours each day, 15 hours / 4 hours each day = 3.75\nThey will need to plan to study 4 days to allow for all the time they need.\nThe answer is 4",
        ),
        (
            "Mark's basketball team scores 25 2 pointers, 8 3 pointers and 10 free throws.  Their opponents score double the 2 pointers but half the 3 pointers and free throws.  What's the total number of points scored by both teams added together?",
            "Mark's team scores 25 2 pointers, meaning they scored 25*2= 50 points in 2 pointers.\nHis team also scores 6 3 pointers, meaning they scored 8*3= 24 points in 3 pointers\nThey scored 10 free throws, and free throws count as one point so they scored 10*1=10 points in free throws.\nAll together his team scored 50+24+10= 84 points\nMark's opponents scored double his team's number of 2 pointers, meaning they scored 50*2=100 points in 2 pointers.\nHis opponents scored half his team's number of 3 pointers, meaning they scored 24/2= 12 points in 3 pointers.\nThey also scored half Mark's team's points in free throws, meaning they scored 10/2=5 points in free throws.\nAll together Mark's opponents scored 100+12+5=117 points\nThe total score for the game is both team's scores added together, so it is 84+117=201 points.\nThe answer is 201",
        ),
        (
            "Natalia sold clips to 48 of her friends in April, and then she sold half as many clips in May. How many clips did Natalia sell altogether in April and May?",
            "Natalia sold 48/2 = 24 clips in May. Natalia sold 48+24 = 72 clips altogether in April and May. The answer is 72"
        ),
        (
            "Bella has two times as many marbles as frisbees. She also has 20 more frisbees than deck cards. If she buys 2/5 times more of each item, what would be the total number of the items she will have if she currently has 60 marbles?",
            "When Bella buys 2/5 times more marbles, she'll have increased the number of marbles by 2/5*60 = 24\nThe total number of marbles she'll have is 60+24 = 84\nIf Bella currently has 60 marbles, and she has two times as many marbles as frisbees, she has 60/2 = 30 frisbees.\nIf Bella buys 2/5 times more frisbees, she'll have 2/5*30 = 12 more frisbees.\nThe total number of frisbees she'll have will increase to 30+12 = 42\nBella also has 20 more frisbees than deck cards, meaning she has 30-20 = 10 deck cards\nIf she buys 2/5 times more deck cards, she'll have 2/5*10 = 4 more deck cards.\nThe total number of deck cards she'll have is 10+4 = 14\nTogether, Bella will have a total of 14+42+84 = 140 items.\nThe answer is 140",
        ),
    ]
    examples['math'] = [
        (
            "The sum of two numbers is 6. The difference of their squares is 12. What is the positive difference of the two numbers?",
            """Call the two numbers $x$ and $y$.\nWe are given that $x+y = 6$ and $x^2 - y^2 = 12$.\nBecause $x^2 - y^2$ factors into $(x+y)(x-y)$, we can substitute in for $x+y$, giving $6(x-y) = 12$, or $x-y = 2$.\nThe answer is 2"""
        ),
        (
            "Which integer is closest to the cube root of 100?",
            """Either 4 or 5 is closest to $\\sqrt[3]{100}$, since $4^3=64$ and $5^3=125$. Since $4.5^3=91.125<100$, $\\sqrt[3]{100}$ is closer to 5 than to 4.\nThe answer is 5"""
        ),
        (
            "What is the value of $(x - y)(x + y)$ if $x = 10$ and $y = 15$?",
            """$(x-y)(x+y)=(10-15)(10+15) = (-5)(25) = -125$.\nThe answer is -125"""
        ),
        (
            "If $g(x) = 3x + 7$ and $f(x) = 5x - 9$, what is the value of $f(g(8))$?",
            """$g(8)=3(8)+7=24+7=31$. Thus, $f(g(8))=f(31)=5(31)-9=155-9=146$.\nThe answer is 146"""),
        (
            "What is the greatest possible positive integer value of $x$ if $\displaystyle\frac{x^4}{x^2} < 10$?",
            """On the left-hand side, $x^2$ cancels, reducing the inequality to $x^2<10$. Since  $3^2=9<10$ while $4^2=16>10$, the greatest possible value of $x$ is 3$.\nThe answer is 3"""
        ),
        (
            "A scale drawing of a park shows that one inch represents 800 feet. A line segment in the drawing that is 4.75 inches long represents how many feet?",
            """Each inch of the 4.75-inch line segment represents 800 feet, so the whole line segment represents $4.75\\times800=\\frac{19}{4}\cdot800=19\cdot200=3800$ feet.\nThe answer is 3800"""
        ),
        (
            "In Mr. Abraham's class, $10$ of the $15$ students received an $A$ on the latest exam. If the same ratio of students received an $A$ on Mrs. Berkeley's latest exam, and if Mrs. Berkeley has $24$ students total, how many students in Mrs. Berkeley's class received an $A$?",
            """If $10$ of $15$ students received an $A$, then the ratio of students receiving an $A$ to students not receiving an $A$ is $\\frac{10}{15}$, or $\\frac{2}{3}$. Let $x$ be the number of students in Mrs. Berkeley's class who received an $A$. Since the ratio is consistent across the two classes, $\\frac{2}{3} = \\frac{x}{24}$. Cross-multiplying yields $x = \\frac{24\cdot 2}{3}$, so, by simplification, we can see that 16 of Mrs. Berkeley's students must have received an $A$.\nThe answer is 16"""
        ),
        (
            "Find the value of the first term in the geometric sequence $a,b,c,32,64$.",
            """The common ratio is $\\frac{64}{32} = 2$. Therefore, the first term is $\\frac{32}{2^3} = \\frac{32}{8} = 4$. \nThe answer is 4"""
        )
    ]
    examples['aqua'] = [
        (
            "John found that the average of 15 numbers is 40. If 10 is added to each number then the mean of the numbers is?\nAnswer Choices: (A) 50 (B) 45 (C) 65 (D) 78 (E) 64",
            "If 10 is added to each number, then the mean of the numbers also increases by 10. So the new mean would be 50. The answer is (A)."
        ),
        (
            "If a / b = 3/4 and 8a + 5b = 22,then find the value of a.\nAnswer Choices: (A) 1/2 (B) 3/2 (C) 5/2 (D) 4/2 (E) 7/2",
            "a / b = 3/4, then b = 4a / 3. So 8a + 5(4a / 3) = 22. This simplifies to 8a + 20a / 3 = 22, which means 44a / 3 = 22. So a is equal to 3/2. The answer is (B)."
        ),
        (
            "A person is traveling at 20 km/hr and reached his destiny in 2.5 hr then find the distance?\nAnswer Choices: (A) 53 km (B) 55 km (C) 52 km (D) 60 km (E) 50 km",
            "The distance that the person traveled would have been 20 km/hr * 2.5 hrs = 50 km. The answer is (E)."
        ),
        (
            "How many keystrokes are needed to type the numbers from 1 to 500?\nAnswer Choices: (A) 1156 (B) 1392 (C) 1480 (D) 1562 (E) 1788",
            "There are 9 one-digit numbers from 1 to 9. There are 90 two-digit numbers from 10 to 99. There are 401 three-digit numbers from 100 to 500. 9 + 90(2) + 401(3) = 1392. The answer is (B)."
        ),
    ]
    examples['sat'] = [
        (
            "If $\frac{x-1}{3}=k$ and $k=3$, what is the value of $x$ ? \nAnswer Choices: (A) 2 (B) 4 (C) 9 (D) 10",
            "If k = 3, then x - 1 = 3 * 3, therfore, x - 1 = 9 and x = 10. The answer is D",
        ),
        (
            "For $i=\sqrt{-1}$, what is the sum $(7+3 i)+(-8+9 i)$ ? \nAnswer Choices: (A) $-1+12 i$ (B) $-1-6 i$ (C) $15+12 i$ (D) $15-6 i$ 3",
            "For (7+3 i)+(-8+9 i), the real part is 7 + (-8) = -1, the imageinary part is 3 i + 9 i = 12 i. The answer is A",
        ),
        (
            "On Saturday afternoon, Armand sent $m$ text messages each hour for 5 hours, and Tyrone sent $p$ text messages each hour for 4 hours. Which of the following represents the total number of messages sent by Armand and Tyrone on Saturday afternoon?\nAnswer Choices: (A) $9 m p$ (B) $20 m p$ (C) $5 m+4 p$ (D) $4 m+5 p$",
            "Armand texts m messages each hour for 5 hours, which leads to 5m messages. Tyrone texts p messages each hour for 4 hours, which leds to 4p messages. The total is 5m + 4p. The answer is C.",
        ),
        (
            "$$\begin{array}{r}3 x+4 y=-23 \\2 y-x=-19\end{array}$$What is the solution $(x, y)$ to the system of equations above?\nAnswer Choices: (A) $(-5,-2)$ (B) $(3,-8)$ (C) $(4,-6)$ (D) $(9,-6)$",
            "By solving this equation, we found that x = 3 and y = -8. The answer is B.",
        )
    ]
    examples["mmlu_mathematics"] = [
        (
            "Simplify and write the result with a rational denominator: $$\sqrt{\sqrt[3]{\sqrt{\frac{1}{729}}}}$$\nAnswer Choices: (A) \frac{3\sqrt{3}}{3} (B) \frac{1}{3} (C) \sqrt{3} (D) \frac{\sqrt{3}}{3}",
            "Factoring $729=3^6$ and combining the roots $\frac{1}{2}\frac{1}{3}\frac{1}{2}=\frac{1}{12}$, we get that $\sqrt{\sqrt[3]{\sqrt{\frac{1}{729}}}}=\left(\frac{1}{3^6}\right)^{\frac{1}{12}}=\frac{1}{3^{\frac{1}{2}}}=\frac{3}{\sqrt{3}}$. The answer is (D)."
        ),
        (
            "Five thousand dollars compounded annually at an $x\%$ interest rate takes six years to double. At the same interest rate, how many years will it take $\$300$ to grow to $\$9600$?\nAnswer Choices:(A) 12 (B) 1 (C) 30 (D) 5",
            "To go from $\$300$ to $\$9600$, the value must go up by a factor of $9600/300=32=2^5$. Since at this interest rate it takes six years for it to double, it will take $5*6=30$ years to grow to $\$9600$. The answer is (C)."
        ),
        (
            "Ten students take a biology test and receive the following scores: 45, 55, 50, 70, 65, 80, 40, 90, 70, 85. What is the mean of the students’ test scores?\nAnswer Choices: (A) 55 (B) 60 (C) 62 (D) 65",
            "There are 10 students and the sum of their scores is $45 + 55 + 50 + 70 + 65 + 80 + 40 + 90 + 70 + 85 = 650$, the mean is $650/10=65$. The answer is (D)."
        ),
        (
            "The variable $x$ varies directly as the square of $y$, and $y$ varies directly as the cube of $z$. If $x$ equals $-16$ when $z$ equals 2, what is the value of $x$ when $z$ equals $\frac{1}{2}$?\nAnswer Choices: (A) -1 (B) 16 (C) -\frac{1}{256} (D) \frac{1}{16}",
            "We know that $x \propto y^2$ and $y \propto z^3$, so $x = k z^6$ for some constant $k$. Plugging in for $x=-16$ and $z=2$, the constant value is $k=\frac{x}{z^6}=\frac{-16}{64}=-\frac{1}{4}$. So, when $z=\frac{1}{2}$, the value of $x$ is $x=kz^6=-\frac{1}{4}\frac{1}{2^6}=-\frac{1}{256}$. The answer is (C).",
        ),
        (
            "Joe was in charge of lights for a dance. The red light blinks every two seconds, the yellow light every three seconds, and the blue light every five seconds. If we include the very beginning and very end of the dance, how many times during a seven minute dance will all the lights come on at the same time? (Assume that all three lights blink simultaneously at the very beginning of the dance.)\nAnswer Choices: (A) 3 (B) 15 (C) 6 (D) 5",
            "The least common multiple of 2, 3 and 5 is 30, so during a 7 minute dance, all the three lights will come on at the same time $2*7+1=15$ times. The answer is (B)."
        )
    ]
    examples['svamp'] = [
        (
            'children were riding on the bus. At the bus stop 82 children got on the bus while some got off the bus. Then there were 30 children altogether on the bus. How many more children got on the bus than those that got off?',
            'Let\'s assume there are x students getting on the bus and y students getting off the bus, than 28 + x - y = 30. Therefore, x - y = 30 - 28 = 2. The answer is 2.'),
        (
            'Mary is baking a cake. The recipe calls for 11 cups of flour and 7 cups of sugar. She already put in some cups of flour. If she still needs 2 more cups of flour than sugar, How many cups of flour did she put in?',
            'Let\'s assume there are x cups of clour already added, so we know 11  - x is the remaining cups of flour. Since the reminaing cups of flour is 2 more than sugar. Then we have 11 - x - 2 = 7. Therefore, x = 11 - 2 - 7 = 2. The answer is 2.',
        ),
        (
            'Frank put 11 pieces of candy in each bag. If he had 22 pieces of candy. How many bags would he have?',
            'Let\'s assume there are x bags. Then we know 11 * x = 22. Therefore, x = 22 / 11 = 2. The answer is 2.'
        ),
        (
            'A farmer had 90 tomatoes in his garden. If he picked 154 of them yesterday and 50 today. How many tomatoes did he pick in all?',
            'The number of tomatoes picked is x = 154 + 50. Therefore, x = 204. The answer is 204.'
        ),
        (
            'The grasshopper, the frog and the mouse had a jumping contest. The grasshopper jumped 19 inches. The frog jumped 10 inches farther than the grasshopper and the mouse jumped 20 inches farther than the frog. How much farther did the mouse jump than the grasshopper?',
            'frog jumps 19 + 10 = 29 inches. The mouse jumps 29 + 20 = 49 inches. Thefore, the mouse jumps 49 - 19 = 30 inches farther than grasshopper. The answer is 30.',
        ),
        (
            'Allan brought 3 balloons and Jake brought 5 balloons to the park. Allan then bought 2 more balloons at the park. How many balloons did Allan and Jake have in the park?',
            'Allan has 3 + 2 = 5 ballons. Jake as 5 ballons. Therefore, the total ballons is 5 + 5 = 10. The answer is 10.',
        ),
        (
            'Jake has 7 fewer peaches than Steven and 9 more peaches than Jill. Steven has 16 peaches. How many peaches does Jake have?',
            'Let\'s assume Jake has x peaches. x + 7 = 16. Therefore, x = 16 - 7 = 9. The answer is 9.'
        ),
        (
            'Katie had 57 new games and 39 old games. Her friends had 34 new games. How many more games does Katie have than her friends?',
            'Katie has a total of 57 + 39 = 96 games. Therefore, Katie has 96 - 34 = 62 games than her friend. The answer is 62.'
        )
    ]
    
    examples['numglue'] = examples['svamp'][:6] + examples['aqua'][:2]
    examples['simuleq'] = examples['svamp']

    return examples[task][:num_shots]